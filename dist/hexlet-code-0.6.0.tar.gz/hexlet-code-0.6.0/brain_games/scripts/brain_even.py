#!/usr/bin/env python
from brain_games.logics_brain_even import parity_check


def main():
    parity_check()


if __name__ == "__main__":
    main()
