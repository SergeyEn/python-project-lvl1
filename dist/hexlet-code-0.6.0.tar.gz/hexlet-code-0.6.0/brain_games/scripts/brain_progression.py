#!/usr/bin/env python
from brain_games.games.logics_brain_progression import log_progression


def main():
    log_progression()


if __name__ == "__main__":
    main()
