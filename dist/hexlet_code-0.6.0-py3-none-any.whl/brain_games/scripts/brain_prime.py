#!/usr/bin/env python
from brain_games.games.logics_brain_prime import log_prime


def main():
    log_prime()


if __name__ == "__main__":
    main()
